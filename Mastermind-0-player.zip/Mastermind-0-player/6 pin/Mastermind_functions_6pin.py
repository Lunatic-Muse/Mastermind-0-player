import random
from random import randint
import itertools
Computer_Guess_answer = [0,0,0,0,0,0]
Cali = [0,0] #Computer Algorithim List
C = [0,0]
Length = 0
R = 0
Le = 0
Position_Shift = 1
GN = 0


def Generate_Correct_Code(correct_answer):
    for x in range(6):
        correct_answer[x] = randint(1, 6)
    #print("V2",correct_answer)
    return correct_answer

################################################################################################################################################################
################################################################################################################################################################
################################################################################################################################################################

def Generate_Guess(Cali):
    #Length = len(Cali)
    Computer_Guess_answer = random.choice(Cali)
#    print("Test C",Cali)
#    R = randint(0,10)
#    print(R)
#    print("tester",Cali[0])
#    print(Cali[0])
    #Computer_Guess_answer = Cali[0]
    #print(Computer_Guess_answer)
    return Computer_Guess_answer

################################################################################################################################################################
################################################################################################################################################################
################################################################################################################################################################

def Generate_Permutations(P0):
    #Init Variables
    Al1_possible_combinations = [0]
    #Define Set
    s=[ P0,P0,P0,P0,P0,P0]
    Cali = list(itertools.product(*s))
    #print(Cali)
    return Cali

################################################################################################################################################################
################################################################################################################################################################
################################################################################################################################################################
    
def prompt_player():
    #Init Variables
    Guess_digit = 0
    guess_answer = [0,0,0,0,0,0]
    N = 0 #place holder used to check
    ###############################################

    ###Prompt Player
    print("please enter each digit your guess one at a time, each digit should be in the range 1-6")

    for x in range(6):
        Guess_digit = input("please enter the next digit(1-6) of your guess     ")
        try:
            if int(Guess_digit) < 7 and int(Guess_digit) > 0:
                guess_answer[x] = int(Guess_digit)
                #N=1
                #guess_answer[0] = 1

            else:
                print("User input invalid please restart guess from 1st digit")
                #guess_answer[4] = 0
                return guess_answer, N

        except ValueError:
            print("User input invalid please restart guess from 1st digit")
            return guess_answer, N
    N = 1
    print(guess_answer)
    return guess_answer[0],guess_answer[1],guess_answer[2],guess_answer[3], N
    #return guess_answer

################################################################################################################################################################
################################################################################################################################################################
################################################################################################################################################################


def grade(guess_answer, correct_answer, GN): #GN should be renamed

    ###Initialize Variables####
    White_pins = [0,0,0,0,0,0]
    correct_answer_labels = [1,2,3,4,5,6]
    correct_pins = [0,0,0,0,0,0] 
    guess_pins = [0,0,0,0,0,0]
    WP = 0
    B = 0
    ###########################
    GN += 1
    for x in range(6):
         for y in range(6):

            if correct_answer[x] == correct_answer_labels[y]: 
                #Y+1 should really be label of Y+1 (i.e. blue, black, etc)
                #here they are the same but this could be rewritten to rely on a named list or a pair of lists with one list containing names
                correct_pins[y] += 1
            if guess_answer[x] == correct_answer_labels[y]:#Same thing as above here. Replace with guess_answer_lables or even just replace both with answer_labels
                guess_pins[y] += 1
 
    for x in range(6):
        #This if/else statement can likely be replaced by something like
        #White_pins[x] = min(correct_pins[x], guess_pins[x])
        if correct_pins[x] > guess_pins[x]: 
            
            White_pins[x] = guess_pins[x]
        else:
           White_pins[x] = correct_pins[x]
           
    WP = sum(White_pins) #Use long variable names
########################################
    for x in range(6):
        if correct_answer[x] == guess_answer[x]:
            B +=1
    TrueWP = WP - B
    if GN > 0:
        print("black pins =",B)
    
        print ("White pins =", TrueWP)
###########################################    
    if B == 6:
#        if GN > 0:
            #print ("correct")
        
            #print ("game reseting")
        return (B,TrueWP,1,GN) #You always want to return the same variables (I think). Maybe have temporary variables set in if/else and then just go to one return. Easier to trace errors
    #elif GN == 10:
        #print ("ran out of guesses try again")

        #print ("game reseting")
        return (B,TrueWP,1,GN)

    else:
        #print("test")
        return (B,TrueWP,0,GN)

################################################################################################################################################################
################################################################################################################################################################
################################################################################################################################################################

def Computer_List_Grade_New(Computer_Algorithim_List,Correct_Black,Correct_White,guess_answer): #Long variables name(cali, B,W)
    #Init
    Pin_list = [0,1,0,2]
    Le = len(Computer_Algorithim_List) 
    Position_Shift = 0
    Number_removed = 0
    Number_tested = 0
    #print("CALi", Computer_Algorithim_List)
    #print("Length is",Le)
    for x in range(Le):
        try:
            Number_tested +=1
            CGB = 0 #computer graded black
            CGW = 0 #computer graded black
            C = Computer_Algorithim_List[Position_Shift]
            #print(C)
            #print(C[0])
            Pin_list = grade(guess_answer, C, -100)
            CGB = Pin_list[0]
            CGW = Pin_list[1]
            if CGW == Correct_White and CGB == Correct_Black:
                pass
                Position_Shift +=1
            else:
                Computer_Algorithim_List.remove(C)
                Number_removed +=1
            #print("removal test", Computer_Algorithim_List)
        except ValueError:
            pass
    #print(Computer_Algorithim_List)
    #print("#removed",Number_removed)
    return(Computer_Algorithim_List)

#This can likely be constructed way more concisely by leveraging grade function
#For n in range 1296 (replace 1296 with length of permutations)
#Grade permutation[n]
#If equal to graded result of guess then possible[n] = 1 else 0
#Remove permutations[n] if possible [n] = 0 (SQL type functions can do this in a line of code, otherwise you likely need a for loop) Maybe one line of code depending on built in list functions








####################################################
def Computer_List_Grade_0ld(Cali,B,W,guess_answer): #Long variables name(cali, B,W)

#This can likely be constructed way more concisely by leveraging grade function
#For n in range 1296 (replace 1296 with length of permutations)
#Grade permutation[n]
#If equal to graded result of guess then possible[n] = 1 else 0
#Remove permutations[n] if possible [n] = 0 (SQL type functions can do this in a line of code, otherwise you likely need a for loop) Maybe one line of code depending on built in list functions

    ###Initialize Variables####
    C_White_pins = [0,0,0,0,0,0]
    C_correct_pins = [0,0,0,0,0,0]
    C_guess_pins = [0,0,0,0,0,0]
    Le = len(Cali) #Long variables name
    Position_Shift = 0
    CGB = 0 #Long variables name
    CGW = 0 #Long variables name
    TrueCGB = 0 #Long variables name
    ###########################
    
    for x in range(Le):
        try:
            CGB = 0
            CGW = 0
            C = Cali[Position_Shift]
           

            for x in range(4):
                 for y in range(6):

                    if C[x] == y+1:
                        C_correct_pins[y] += 1
                    if guess_answer[x] == y:
                        C_guess_pins[y] += 1
            
            for x in range(6):
                if C_correct_pins[x] > C_guess_pins[x]:
                    C_White_pins[x] = C_guess_pins[x]
                else:
                   C_White_pins[x] = C_correct_pins[x]
                   
            CGW = sum(C_White_pins)

            for x in range(4):
                if C[x] == guess_answer[x]:
                    CGB +=1
                

            TrueCGW = CGW - CGB
            
            if TrueCGW == W and CGB == B:
                pass
                Position_Shift +=1
            else:
                Cali.remove(C)
            #print(Cali)
        except ValueError:
            pass

    return (Cali)
    
    
    
