######## Import Libraries
import random
import itertools
from Mastermind_functions_6pin import Generate_Guess
from Mastermind_functions_6pin import Generate_Correct_Code
from Mastermind_functions_6pin import Generate_Permutations
from Mastermind_functions_6pin import prompt_player
from Mastermind_functions_6pin import grade
from Mastermind_functions_6pin import Computer_List_Grade_New
import statistics
#######Init Variables

P0 = [1,2,3,4,5,6]
T = [0,0]
correct_answer = [0,0,0,0,0,0]
guess_answer = [0,0,0,0,0,0]
GameWin = 0
BW = [0,0,0,0]
GN = 0
Fail = 0
Guess_Number_Data = [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
                     0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
                     ]
GND = 0
###################################

#Run Code
for y in range(100):
    Cali = Generate_Permutations(P0)
    #print(Al1_possible_combinations[367])
    GN = 1
    GameWin = 0
    #generates secret code
    correct_answer = Generate_Correct_Code(correct_answer) #probably want to move to while loop just above call to grade computer guress

    #Generate guess, in this version generating automatic guess from computer
    computer_guess = Generate_Guess(Cali) #likely redundant with first line in while
    #print("V1",computer_guess)

    #Evaluate guess
    if GameWin == 0: #replace with something like computer_guess[0]
        while True: #I think true needs to be replaced with (Computer_grade_output[?]=0) and remove if statement
            computer_guess = Generate_Guess(Cali) # can likely be moved after next line
            print("Guess number",GN)
            print("guess generated")
    ##I think everything below can be replaced with calling Computer_List_Grade_New
    #computer_guess = Generate_Guess(Cali)
    #Computer_grade_output = Computer_List_Grade_New(inputs)

    #Shouldn't need anything below this
    #When while loop ends, game is over.
            ##right now grade handles game over logic but that can be its own function called after while loop
            


            
    ##        T = prompt_player()
    ##        print(T)
    ##        if int(T[1]) == 0:
    ##            while True:
    ##                print(T)
    ##                T = prompt_player()
    ##                if T[4] == 1:
    ##                    break
            for x in range(6):
                guess_answer[x] = computer_guess[x]
            #ask player for guess

            #print("test")        
            BW = grade(guess_answer,correct_answer,GN)
            GN = BW[3]
            if BW[2] == 1:
                #GameWin = 1
                print("win")
                break
            print(correct_answer)
            Cali = Computer_List_Grade_New(Cali,BW[0],BW[1],computer_guess)
            print("test")

    Guess_Number_Data[y] = GN
    if GN > 7:
        Fail +=1
print(Guess_Number_Data)
GND = sum(Guess_Number_Data)/len(Guess_Number_Data)
print("Median:",statistics.median(Guess_Number_Data))
print("Mean",GND)
print(Fail)
    
    
    


